const user = require('../model/user');

const signUp = (req, res) => {
    const User = new user({

    });
};